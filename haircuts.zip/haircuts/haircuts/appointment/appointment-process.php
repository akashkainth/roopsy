<?php

define("WEBMASTER_EMAIL", 'rollthemes@gmail.com');

$error = false;
$fields = array( 'appointment_name', 'appointment_phone', 'appointment_mail');

foreach ( $fields as $field ) {	
	if ( empty($_POST[$field]) || trim($_POST[$field]) == '' )
		$error = true;
}

if ( !$error ) {
	$name = stripslashes($_POST['appointment_name']);
	$phone = stripslashes($_POST['appointment_phone']);
	$email = trim($_POST['appointment_mail']);
	$services = stripslashes($_POST['appointment_services']);
	$barber = stripslashes($_POST['appointment_barber']);	
	$date = stripslashes($_POST['appointment_date']);
	$time = stripslashes($_POST['appointment_time']);
	$message = "Name:".$name .", ";
	$message .= "Phone:".$phone .", ";
	$message .= "Services:".$services .", ";
	$message .= "Barber:" .$barber. ", ";
	$message .= "Date:"	.$date. ", ";
	$message .= "Time:" .$time. ", ";	
	$mail = @mail(WEBMASTER_EMAIL, "You have a new message.", $message,
		"From: " . $name . " <" . $email . ">\r\n"
		."Reply-To: " . $email . "\r\n"
		."X-Mailer: PHP/" . phpversion());

	if ( $mail ) {
		echo 'Success';
	} else {
		echo $error;
	}
}

?>